# EntregaRapidaEstudo
Estudo do projeto Entrega Rapida

Projeto REST de estudo em PHP para SlimFramework com ORM Eloquent.

- Objetivo do projeto: Cadastro de usuários, empresas e produtos.

- Objetivo do estudo: Identificar e aplicar praticas REST com ORM Eloquent.


